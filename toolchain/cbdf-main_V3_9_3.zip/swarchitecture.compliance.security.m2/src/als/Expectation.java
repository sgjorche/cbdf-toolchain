/**
 */
package als;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expectation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link als.Expectation#getExpect <em>Expect</em>}</li>
 *   <li>{@link als.Expectation#getValue <em>Value</em>}</li>
 * </ul>
 *
 * @see als.AlsPackage#getExpectation()
 * @model
 * @generated
 */
public interface Expectation extends EObject {
	/**
	 * Returns the value of the '<em><b>Expect</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Expect</em>' attribute.
	 * @see #setExpect(String)
	 * @see als.AlsPackage#getExpectation_Expect()
	 * @model
	 * @generated
	 */
	String getExpect();

	/**
	 * Sets the value of the '{@link als.Expectation#getExpect <em>Expect</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Expect</em>' attribute.
	 * @see #getExpect()
	 * @generated
	 */
	void setExpect(String value);

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(int)
	 * @see als.AlsPackage#getExpectation_Value()
	 * @model
	 * @generated
	 */
	int getValue();

	/**
	 * Sets the value of the '{@link als.Expectation#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(int value);

} // Expectation

/**
 */
package als;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Comma</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link als.Comma#getComma <em>Comma</em>}</li>
 * </ul>
 *
 * @see als.AlsPackage#getComma()
 * @model
 * @generated
 */
public interface Comma extends EObject {
	/**
	 * Returns the value of the '<em><b>Comma</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Comma</em>' attribute.
	 * @see #setComma(String)
	 * @see als.AlsPackage#getComma_Comma()
	 * @model
	 * @generated
	 */
	String getComma();

	/**
	 * Sets the value of the '{@link als.Comma#getComma <em>Comma</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Comma</em>' attribute.
	 * @see #getComma()
	 * @generated
	 */
	void setComma(String value);

} // Comma

/**
 */
package als.impl;

import als.AlsPackage;
import als.Comma;
import als.ExactlyName;
import als.LeftSquareBracketKeyword;
import als.RightSquareBracketKeyword;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Module</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link als.impl.ModuleImpl#getModuleName <em>Module Name</em>}</li>
 *   <li>{@link als.impl.ModuleImpl#getLeft <em>Left</em>}</li>
 *   <li>{@link als.impl.ModuleImpl#getExactly <em>Exactly</em>}</li>
 *   <li>{@link als.impl.ModuleImpl#getName <em>Name</em>}</li>
 *   <li>{@link als.impl.ModuleImpl#getComma <em>Comma</em>}</li>
 *   <li>{@link als.impl.ModuleImpl#getNumber <em>Number</em>}</li>
 *   <li>{@link als.impl.ModuleImpl#getRight <em>Right</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ModuleImpl extends EObjectImpl implements als.Module {
	/**
	 * The default value of the '{@link #getModuleName() <em>Module Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModuleName()
	 * @generated
	 * @ordered
	 */
	protected static final String MODULE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getModuleName() <em>Module Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModuleName()
	 * @generated
	 * @ordered
	 */
	protected String moduleName = MODULE_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getLeft() <em>Left</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLeft()
	 * @generated
	 * @ordered
	 */
	protected LeftSquareBracketKeyword left;

	/**
	 * The cached value of the '{@link #getExactly() <em>Exactly</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExactly()
	 * @generated
	 * @ordered
	 */
	protected EList<String> exactly;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected EList<ExactlyName> name;

	/**
	 * The cached value of the '{@link #getComma() <em>Comma</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComma()
	 * @generated
	 * @ordered
	 */
	protected EList<Comma> comma;

	/**
	 * The cached value of the '{@link #getNumber() <em>Number</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumber()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> number;

	/**
	 * The cached value of the '{@link #getRight() <em>Right</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRight()
	 * @generated
	 * @ordered
	 */
	protected RightSquareBracketKeyword right;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ModuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AlsPackage.Literals.MODULE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getModuleName() {
		return moduleName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setModuleName(String newModuleName) {
		String oldModuleName = moduleName;
		moduleName = newModuleName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AlsPackage.MODULE__MODULE_NAME, oldModuleName, moduleName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LeftSquareBracketKeyword getLeft() {
		return left;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLeft(LeftSquareBracketKeyword newLeft, NotificationChain msgs) {
		LeftSquareBracketKeyword oldLeft = left;
		left = newLeft;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AlsPackage.MODULE__LEFT, oldLeft, newLeft);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLeft(LeftSquareBracketKeyword newLeft) {
		if (newLeft != left) {
			NotificationChain msgs = null;
			if (left != null)
				msgs = ((InternalEObject)left).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - AlsPackage.MODULE__LEFT, null, msgs);
			if (newLeft != null)
				msgs = ((InternalEObject)newLeft).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - AlsPackage.MODULE__LEFT, null, msgs);
			msgs = basicSetLeft(newLeft, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AlsPackage.MODULE__LEFT, newLeft, newLeft));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<String> getExactly() {
		if (exactly == null) {
			exactly = new EDataTypeEList<String>(String.class, this, AlsPackage.MODULE__EXACTLY);
		}
		return exactly;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<ExactlyName> getName() {
		if (name == null) {
			name = new EObjectContainmentEList<ExactlyName>(ExactlyName.class, this, AlsPackage.MODULE__NAME);
		}
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Comma> getComma() {
		if (comma == null) {
			comma = new EObjectContainmentEList<Comma>(Comma.class, this, AlsPackage.MODULE__COMMA);
		}
		return comma;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getNumber() {
		if (number == null) {
			number = new EDataTypeEList<Integer>(Integer.class, this, AlsPackage.MODULE__NUMBER);
		}
		return number;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RightSquareBracketKeyword getRight() {
		return right;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRight(RightSquareBracketKeyword newRight, NotificationChain msgs) {
		RightSquareBracketKeyword oldRight = right;
		right = newRight;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AlsPackage.MODULE__RIGHT, oldRight, newRight);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRight(RightSquareBracketKeyword newRight) {
		if (newRight != right) {
			NotificationChain msgs = null;
			if (right != null)
				msgs = ((InternalEObject)right).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - AlsPackage.MODULE__RIGHT, null, msgs);
			if (newRight != null)
				msgs = ((InternalEObject)newRight).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - AlsPackage.MODULE__RIGHT, null, msgs);
			msgs = basicSetRight(newRight, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AlsPackage.MODULE__RIGHT, newRight, newRight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AlsPackage.MODULE__LEFT:
				return basicSetLeft(null, msgs);
			case AlsPackage.MODULE__NAME:
				return ((InternalEList<?>)getName()).basicRemove(otherEnd, msgs);
			case AlsPackage.MODULE__COMMA:
				return ((InternalEList<?>)getComma()).basicRemove(otherEnd, msgs);
			case AlsPackage.MODULE__RIGHT:
				return basicSetRight(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AlsPackage.MODULE__MODULE_NAME:
				return getModuleName();
			case AlsPackage.MODULE__LEFT:
				return getLeft();
			case AlsPackage.MODULE__EXACTLY:
				return getExactly();
			case AlsPackage.MODULE__NAME:
				return getName();
			case AlsPackage.MODULE__COMMA:
				return getComma();
			case AlsPackage.MODULE__NUMBER:
				return getNumber();
			case AlsPackage.MODULE__RIGHT:
				return getRight();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AlsPackage.MODULE__MODULE_NAME:
				setModuleName((String)newValue);
				return;
			case AlsPackage.MODULE__LEFT:
				setLeft((LeftSquareBracketKeyword)newValue);
				return;
			case AlsPackage.MODULE__EXACTLY:
				getExactly().clear();
				getExactly().addAll((Collection<? extends String>)newValue);
				return;
			case AlsPackage.MODULE__NAME:
				getName().clear();
				getName().addAll((Collection<? extends ExactlyName>)newValue);
				return;
			case AlsPackage.MODULE__COMMA:
				getComma().clear();
				getComma().addAll((Collection<? extends Comma>)newValue);
				return;
			case AlsPackage.MODULE__NUMBER:
				getNumber().clear();
				getNumber().addAll((Collection<? extends Integer>)newValue);
				return;
			case AlsPackage.MODULE__RIGHT:
				setRight((RightSquareBracketKeyword)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AlsPackage.MODULE__MODULE_NAME:
				setModuleName(MODULE_NAME_EDEFAULT);
				return;
			case AlsPackage.MODULE__LEFT:
				setLeft((LeftSquareBracketKeyword)null);
				return;
			case AlsPackage.MODULE__EXACTLY:
				getExactly().clear();
				return;
			case AlsPackage.MODULE__NAME:
				getName().clear();
				return;
			case AlsPackage.MODULE__COMMA:
				getComma().clear();
				return;
			case AlsPackage.MODULE__NUMBER:
				getNumber().clear();
				return;
			case AlsPackage.MODULE__RIGHT:
				setRight((RightSquareBracketKeyword)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AlsPackage.MODULE__MODULE_NAME:
				return MODULE_NAME_EDEFAULT == null ? moduleName != null : !MODULE_NAME_EDEFAULT.equals(moduleName);
			case AlsPackage.MODULE__LEFT:
				return left != null;
			case AlsPackage.MODULE__EXACTLY:
				return exactly != null && !exactly.isEmpty();
			case AlsPackage.MODULE__NAME:
				return name != null && !name.isEmpty();
			case AlsPackage.MODULE__COMMA:
				return comma != null && !comma.isEmpty();
			case AlsPackage.MODULE__NUMBER:
				return number != null && !number.isEmpty();
			case AlsPackage.MODULE__RIGHT:
				return right != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (moduleName: ");
		result.append(moduleName);
		result.append(", exactly: ");
		result.append(exactly);
		result.append(", number: ");
		result.append(number);
		result.append(')');
		return result.toString();
	}

} //ModuleImpl

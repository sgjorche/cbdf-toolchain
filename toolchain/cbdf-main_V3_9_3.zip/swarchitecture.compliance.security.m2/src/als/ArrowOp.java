/**
 */
package als;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arrow Op</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link als.ArrowOp#getArrow <em>Arrow</em>}</li>
 * </ul>
 *
 * @see als.AlsPackage#getArrowOp()
 * @model
 * @generated
 */
public interface ArrowOp extends EObject {
	/**
	 * Returns the value of the '<em><b>Arrow</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Arrow</em>' attribute.
	 * @see #setArrow(String)
	 * @see als.AlsPackage#getArrowOp_Arrow()
	 * @model
	 * @generated
	 */
	String getArrow();

	/**
	 * Sets the value of the '{@link als.ArrowOp#getArrow <em>Arrow</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Arrow</em>' attribute.
	 * @see #getArrow()
	 * @generated
	 */
	void setArrow(String value);

} // ArrowOp
